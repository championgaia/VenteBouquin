﻿namespace M02_Conteneurs
{
    public partial class App
    {
    }
}
