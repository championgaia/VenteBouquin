﻿using System.Windows;

namespace M04_DataBinding
{
    public partial class App : Application
    {
    }
}
