﻿using System.Windows;

namespace Exo_Morpion
{
    public partial class App : Application
    {
    }
}
