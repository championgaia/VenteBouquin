$(function() {

	//----------------
	// Naviguer dans le document HTML :

	// Les méthodes next() et children() :
	// Au clic sur un <h3> "effacer galerie X", la galerie qui suit immédiatement s'efface :
	$('#galeries h3').click(function() {

		// $(this).next().fadeOut(1000); // la méthode next() permet de sélectionner la balise directement suivante, ici la div.galerie qui suit le h3 sur lequel on a cliqué (= this). next() peut prendre un sélecteur en argument pour ne sélectionner que les balises suivantes répondant à celui-ci (exemple next('p') sélectionne le <p> directement suivant).

		$(this).next().children('img').fadeOut(1000); // children() sélectionne les enfants directs d'une balise, ici toutes les balises <img> qui se trouvent dans la balise div.galerie qui suit le <h3> sur lequel on a cliqué. Sans argument, children() sélectionne TOUS les enfants directs sans distinction. 
	});

	// La méthode parent() :
	$('#galeries img').click(function() {
		$(this).parent().css({ border : '2px solid red' }); // la méthode parent() sélectionne l'élément parent direct d'une balise, ici le div.galerie dont on met la bordure en rouge. Sans argument, parent() sélectionne le parent direct sans distinction.
	});

	// La méthode prev() (pour previous en anglais = précédent) :
	$('#galeries p').click(function() {
		$(this).prev().css({ border : '' });  // la méthode prev() sélectionne l'élément directement précédent, ici le div.galerie dont on réinitialise la bordure en CSS.
	});

	// La méthode find() :
	$('button').eq(0).click(function() {
		$('#galeries').find('img').fadeOut(1000); // la méthode find() sélectionne tous les descendants directs ou indirects correspondant au sélecteur précisé. Ici trouve toutes les balises <img> qui se situent dans la balise div#galeries.		
	});

	
	//---------
	// Exercice "accordéon" :



}); // fin du document ready