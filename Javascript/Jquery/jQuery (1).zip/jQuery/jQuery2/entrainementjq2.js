
// Les ANIMATIONS

$(function() {
	// déclaration d'une fonction utilisateur qui annonce la fin des animations :
	function finAnim() {
		alert('Animation terminée !');
	}


	//------------------
	// Les animations de type FADE : fadeIn(), fadeOut(), fadeToggle(), fadeTo() :
	$('#fadein').click(function() {
		$('#rouge').fadeIn(); // fadeIn() fait apparaître l'élément en fondu en jouant sur l'opacité pendant la durée spécifiée en ms.
		$('#bleu').fadeIn(2000); // 2000 ms
		$('#vert').fadeIn(1000).delay(1000).fadeOut(1000, finAnim); // en jQuery on peut enchaîner les méthodes d'animation les unes à la suite des autres. La fonction finAnim est appelée lorsque le dernier fadeOut a terminé son travail. Il s'agit d'une callback (fonction de retour). Attention : finAnim sans les () sinon elle s'exécute immédiatement sans attendre l'ordre du fadeOut.
	});

	// Au clic sur le bouton #fadeout, l'image #imageDisp disparaît en fondu en 1s :
	$('#fadeout').click(function() {
		$('#imageDisp').fadeOut(1000);
	});

	// fadeToggle() :
	$('#interr').click(function() {
		$('#black').fadeToggle(1000);   // alterne fadeIn() et fadeOut()
	});

	// fadeTo() :
	$('#exo1').click(function() {
		$('#orange').fadeTo(2000, 0.2); // fait une transtion jusqu'à l'opacité indiquée (entre 0 et 1) en 2s
		$('#violet').fadeTo(2000, 0.5);
	});


	//------------------
	// Les animations de type SLIDE : slideDown(), slideUp(), slideToggle() :
	$('#barre').click(function() {
		//$('#rideau').slideDown(1000);  // slideDown() fait apparaître l'élément avec un effet de glissement vers le bas en 1s.
		$('#rideau').stop().slideToggle(1000); // stop() permet d'arrêter une animation enc ours et de démarrer la suivante. Cela évite que le bloc fasse notamment un "effet ressort" lorsqu'on clique plusieurs fois. slideToggle() alterne slideDown() et slideUp().

	});

	//------------------
	// Les animations ANIMATE :
	// Les animations de type animate agissent sur les propriétés CSS numériques. Par exemple : top, left, right, bottom, ou encore opacity, width, height, font-size... Comme par défaut les éléments HTML ont une position "static" en CSS, nous sommes obligés de leur mettre une position "relative" ou "absolute" pour pouvoir utiliser les propriétés permettant de les déplacer.

	$('#anim1').click(function() {
		$('#un').animate({ top : '-200px' }, 1000);  // les propriétés CSS se mettent dans un objet entre {}. Note : si on utilise une propriété CSS contenant un tiret (exemple font-size), il faut écrire cette propriété entre quote dans notre objet. Pour pousser le carré vers le haut, il faut faire décroître la valeur de top : -200px par rapport à la position d'origine.
	});


	// Deux propriétés CSS simultanément dans la même animation :
	$('#anim2').click(function() {
		$('#deux').animate({ top : '-150px', left : '100px' }, 1000);
	});  // quand on met plusieurs propriétés dans le même objet, le navigateur calcule la trajectoire directe entre la position d'origine et la position finale : on obtient donc ici une diagonale. -150px / 100px sont des positions par rapport à la position d'origine.


	// Deux animations consécutives :
	$('#anim3').click(function() {
		$('#trois').animate({ top : '+=100px', left : '+=100px' }, 1000)
		           .animate({ top : '-=100px', left : '+=100px' }, 1000);
	}); // on peut passer un opérateur += ou -= dans la valeur de la propriété CSS dans animate(), ce qui permet de poursuivre l'animation à chaque clic : il s'agit d'une variation en relatif par rapport à la dernière position.


	// Une animation continue :
	function anim4() {
		$('#quatre').animate({ left : '400px' }, 3000)
		            .animate({ left : '0px' }, 3000, anim4); // 0px est la position du carré par rapport à l'origine. Autrement dit, le carré revient à sa position de départ (mouvement vers la gauche). La fonction anim4 s'appelle elle-même dès que la méthode animate() a terminé son animation. Ainsi l'animation est continue.
	}

	$('#anim4').click(anim4); // au clic on appelle la fonction anim4 à laquelle on ne met pas de () pour ne pas qu'elle s'exécute immédiatement.












}); // fin du document ready