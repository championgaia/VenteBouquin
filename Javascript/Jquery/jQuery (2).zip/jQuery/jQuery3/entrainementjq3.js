$(function() {

	//----------------
	// Naviguer dans le document HTML :

	// Les méthodes next() et children() :
	// Au clic sur un <h3> "effacer galerie X", la galerie qui suit immédiatement s'efface :
	$('#galeries h3').click(function() {

		// $(this).next().fadeOut(1000); // la méthode next() permet de sélectionner la balise directement suivante, ici la div.galerie qui suit le h3 sur lequel on a cliqué (= this). next() peut prendre un sélecteur en argument pour ne sélectionner que les balises suivantes répondant à celui-ci (exemple next('p') sélectionne le <p> directement suivant).

		$(this).next().children('img').fadeOut(1000); // children() sélectionne les enfants directs d'une balise, ici toutes les balises <img> qui se trouvent dans la balise div.galerie qui suit le <h3> sur lequel on a cliqué. Sans argument, children() sélectionne TOUS les enfants directs sans distinction. 
	});

	// La méthode parent() :
	$('#galeries img').click(function() {
		$(this).parent().css({ border : '2px solid red' }); // la méthode parent() sélectionne l'élément parent direct d'une balise, ici le div.galerie dont on met la bordure en rouge. Sans argument, parent() sélectionne le parent direct sans distinction.
	});

	// La méthode prev() (pour previous en anglais = précédent) :
	$('#galeries p').click(function() {
		$(this).prev().css({ border : '' });  // la méthode prev() sélectionne l'élément directement précédent, ici le div.galerie dont on réinitialise la bordure en CSS.
	});

	// La méthode find() :
	$('button').eq(0).click(function() {
		$('#galeries').find('img').fadeOut(1000); // la méthode find() sélectionne tous les descendants directs ou indirects correspondant au sélecteur précisé. Ici trouve toutes les balises <img> qui se situent dans la balise div#galeries.		
	});

	
	//---------
	// Exercice "accordéon" :
	$('#accordion h3').click(function () {
		$('.on').removeClass('on').addClass('off');
		$(this).next().removeClass('off').addClass('on');
	});
	

	//---------
	// Déclencher une action au scroll :

	// On veut que les images apparaissent simultanément lors du scroll :
	/* $(document).scroll(function() { // l'événement scroll s'applique directement à l'objet "document".

		//console.log($(document).scrollTop()); // la méthode scrollTop() retourne la position verticale de la barre de défilement du navigateur (nombre de px parcourus depuis le début du document).

		if ($(document).scrollTop() >= 1000) { // si on a scrollé de 1000px ou plus, on affiche les images de classe .scroll avec un fade :
			$('.scroll').fadeIn(1000); // 1000 pour 1s
		} else { // sinon, si on remonte en scrollant, et que j'arrive en-dessous de 1000px j'efface les images :
			$('.scroll').fadeOut(1000);
		}

		console.log($('.scrolls').offset().top); // la méthode offset() possède une propriété "top" qui retourne la position en px entre le haut de l'élément et le début du document. Il existe aussi une propriété left pour la position gauche depuis le bord gauche du document. Attention : cette méthode ne marche que sur des éléments affichés (sinon elle retourne 0).

	}); */


	// Exercice : vous faites apparaître les 4 images successivement quand on scrolle, et disparaître quand on remonte en scrollant. Pour cela, mettez le code précédent en commentaire.

	$(document).scroll(function() {
		$('.scroll').each(function(indice, element) { // on parcourt chaque image de classe .scroll pour vérifier leur position une à une dans le navigateur.

			var hauteur_fenetre = $(window).height(); // calcule la hauteur de navigateur

			if ($(document).scrollTop() >= $(this).parent().offset().top - hauteur_fenetre/2 ) { // si le défilement (scrollTop()) dans le navigateur est supérieur ou égal à la position top du <div> parent de chaque image ($(this).parent().offset().top), alors on fait apparaître l'image ($(this)). La variable hauteur_fenetre/2 permet d'ajuster le déclenchement de l'apparition au milieu de la hauteur du navigateur.
				$(this).fadeIn(1000); // l'image sur laquelle on se trouve à chaque tour de boucle apparaît.
			} else {
				$(this).fadeOut(1000);
			}
		});
	});


	//-----------
	// Scroll automatique au clic sur un élément :
	$('.top').click(function() {
		$('html, body').animate({ scrollTop : '100px' }, 2000); // la propriété scrollTop place le haut de l'élément sélectionné (ici les balises <html> et <body>) à la position indiquée en px par rapport au début du document.
	});

	// Exercice : au clic sur le bouton "Aller à exercice 1", la page scrolle automatiquement jusqu'au bloc "Exercice accordéon" en 2 secondes, sachant que l'id de ce bloc est #exo1.
	$('.top2').click(function() {
		$('html, body').animate({ scrollTop : $('#exo1').offset().top }, 2000);
	});

	

}); // fin du document ready