﻿namespace M01_HelloWorld
{
    public partial class App
    {
    }
}
