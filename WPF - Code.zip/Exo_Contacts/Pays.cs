﻿namespace Exo_Contacts
{
    public class Pays
    {
        public string Nom { get; set; }
    }
}